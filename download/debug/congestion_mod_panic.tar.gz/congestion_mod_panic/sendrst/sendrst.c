#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/version.h>
#include <linux/netfilter.h>
#include <net/tcp.h>


void __tcp_v4_send_check(struct sk_buff *skb, __be32 saddr, __be32 daddr)
{
        struct tcphdr *th = tcp_hdr(skb);

        if (skb->ip_summed == CHECKSUM_PARTIAL) {
                th->check = ~tcp_v4_check(skb->len, saddr, daddr, 0);
                skb->csum_start = skb_transport_header(skb) - skb->head;
                skb->csum_offset = offsetof(struct tcphdr, check);
        } else {
                th->check = tcp_v4_check(skb->len, saddr, daddr,
                                         csum_partial(th,
                                                      th->doff << 2,
                                                      skb->csum));
        }
}

static unsigned int
__cong_out(struct sk_buff *skb,
		  const struct net_device *in, const struct net_device *out,
		  int (*okfn) (struct sk_buff *))
{
	struct iphdr *iph;
	struct tcphdr *th;
	int iph_len;

	if (!pskb_may_pull(skb, 40))
		return NF_ACCEPT;
	iph = ip_hdr(skb);
	th = tcp_hdr(skb);
	if (ntohs(th->source) == 6666 || ntohs(th->dest) == 6666) {
		if (th->psh) {
			th->psh = 0;
			th->rst = 1;

	                th->check = 0;
        	        iph_len = ip_hdrlen(skb);
                	skb_pull(skb, iph_len);
	                __tcp_v4_send_check(skb, iph->saddr, iph->daddr);
        	        skb_push(skb, iph_len);
		}
	}
	return NF_ACCEPT;
}

static unsigned int
cong_out(const struct nf_hook_ops *ops, struct sk_buff *skb,
		  const struct net_device *in, const struct net_device *out,
		  int (*okfn) (struct sk_buff *))
{
	int ret = NF_ACCEPT;
	ret = __cong_out(skb, in, out, okfn);
	return ret;
}

static struct nf_hook_ops cong_ops[] __read_mostly = {
	{
	 .hook     = cong_out,
	 .owner    = THIS_MODULE,
	 .pf       = PF_INET,
#if (LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 32))
	 .hooknum  = NF_INET_LOCAL_OUT,
#else
	 .hooknum  = NF_IP_LOCAL_OUT,
#endif
	 .priority = 100,
	},
};

static int __init cong_init(void)
{
	int ret;
	ret = nf_register_hooks(cong_ops, ARRAY_SIZE(cong_ops));
	if (ret < 0) {
		printk("register err\n");
	}
	return ret;
}

static void __exit cong_exit(void)
{
	nf_unregister_hooks(cong_ops, ARRAY_SIZE(cong_ops));
}

module_init(cong_init);
module_exit(cong_exit);
MODULE_AUTHOR("sendrst");
MODULE_LICENSE("GPL");
