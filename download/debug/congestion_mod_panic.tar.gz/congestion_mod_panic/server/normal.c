#include <linux/mm.h>
#include <linux/module.h>
#include <linux/sysctl.h>
#include <linux/kernel.h>
#include <net/tcp.h>
#include <linux/version.h>


struct normal_t {
	int cc[16];
};

static void normal_init(struct sock *sk)
{
	int i;
	struct normal_t *normal = inet_csk_ca(sk);
	for (i = 0; i < 16; i ++)
		normal->cc[i] = 1;
}

static void normal_release(struct sock *sk)
{
	struct normal_t *normal = inet_csk_ca(sk);
}

static u32 ssthresh(struct sock *sk)
{
	return 10;
}

static void normal_avoid(struct sock *sk, u32 ack, u32 in_flight)
{
}

static struct tcp_congestion_ops normal_test = {
	.init		= normal_init,
	.release	= normal_release,
	.ssthresh	= ssthresh,
	.cong_avoid	= normal_avoid,
	.owner		= THIS_MODULE,
	.name		= "normal",
	
};

static int __init normal_register(void)
{
	BUILD_BUG_ON(sizeof(struct normal_t) > ICSK_CA_PRIV_SIZE);

	return tcp_register_congestion_control(&normal_test);		
}

static void __exit normal_unregister(void)
{
	tcp_unregister_congestion_control(&normal_test);
}

module_init(normal_register);
module_exit(normal_unregister);
MODULE_LICENSE("GPL");
