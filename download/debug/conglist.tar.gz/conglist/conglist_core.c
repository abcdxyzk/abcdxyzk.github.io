#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/tcp.h>
#include <net/tcp.h>
#include <net/protocol.h>
#include <linux/spinlock.h>
#include <linux/kallsyms.h>
#include <linux/kprobes.h>
#include <linux/netfilter.h>
#include <linux/fdtable.h>

#include "conglist_symbols.h"

char sysctl_name[TCP_CA_NAME_MAX] = "hybrid";

int sysctl_set_new_cong = 0;
int set_new_cong_round = 0;
char sysctl_new_cong[TCP_CA_NAME_MAX] = "cubic";

int idx;

int list_process(void __user *buffer, size_t *lenp, size_t *rlen);

static int proc_conglist2(struct ctl_table *table, int write,
		void __user *buffer, size_t *lenp, loff_t *ppos)
{
	size_t wlen      = 0;
	size_t rlen      = 0;

	if (!(*lenp) || (*ppos && !write)) {
		*lenp = 0;
		return 0;
	}

	if (write) {
	} else {
		list_process(buffer, lenp, &rlen);
		*lenp = rlen;
		*ppos += rlen;
	}
	return write ? wlen : rlen;
}

static struct ctl_table_header *conglist_sysctl_head = NULL;

static struct ctl_table conglist_sysctl_table[] = {
	{
		.procname = "name",
		.data = &sysctl_name,
		.maxlen = TCP_CA_NAME_MAX-1,
		.mode = 0644,
		.proc_handler = proc_dostring
	},
	{
		.procname = "set_new_cong",
		.data = &sysctl_set_new_cong,
		.maxlen = sizeof(sysctl_set_new_cong),
		.mode = 0644,
		.proc_handler = proc_dointvec
	},
	{
		.procname = "new_cong",
		.data = &sysctl_new_cong,
		.maxlen = TCP_CA_NAME_MAX-1,
		.mode = 0644,
		.proc_handler = proc_dostring
	},
	{
		.procname = "conglist2",
		.data = NULL,
		.maxlen = 0,
		.mode = 0444,
		.proc_handler = proc_conglist2
	},
	{}
};

int conglist_sysctl_init(void)
{
	conglist_sysctl_head = register_net_sysctl(&init_net, "net/conglist", conglist_sysctl_table);
	return !conglist_sysctl_head;
}

void conglist_sysctl_exit(void)
{
	if (conglist_sysctl_head)
		unregister_net_sysctl_table(conglist_sysctl_head);
	return;
}

static void get_openreq4(const struct sock *sk, const struct request_sock *req,
			 struct seq_file *f, int i, kuid_t uid, int *len)
{
	const struct inet_request_sock *ireq = inet_rsk(req);
	long delta = req->expires - jiffies;

	seq_printf(f, "%4d: %08X:%04X %08X:%04X"
		" %02X %08X:%08X %02X:%08lX %08X %5u %8d %u %d %pK%n",
		i,
		ireq->ir_loc_addr,
		ntohs(inet_sk(sk)->inet_sport),
		ireq->ir_rmt_addr,
		ntohs(ireq->ir_rmt_port),
		TCP_SYN_RECV,
		0, 0, /* could print option size, but that is af dependent. */
		1,    /* timers active (only the expire timer) */
		jiffies_delta_to_clock_t(delta),
		req->num_timeout,
		from_kuid_munged(seq_user_ns(f), uid),
		0,  /* non standard timer */
		0, /* open_requests have no inode */
		atomic_read(&sk->sk_refcnt),
		req,
		len);
}

static void get_tcp4_sock(struct sock *sk, struct seq_file *f, int i, int *len)
{
	int timer_active;
	unsigned long timer_expires;
	const struct tcp_sock *tp = tcp_sk(sk);
	struct inet_connection_sock *icsk = inet_csk(sk);
	const struct inet_sock *inet = inet_sk(sk);
	__be32 dest = inet->inet_daddr;
	__be32 src = inet->inet_rcv_saddr;
	__u16 destp = ntohs(inet->inet_dport);
	__u16 srcp = ntohs(inet->inet_sport);

	if (icsk->icsk_ca_ops) {
		if (strcmp(icsk->icsk_ca_ops->name, sysctl_name))
			return;
		seq_printf(f, "%4d: %08X:%04X %08X:%04X %02X %s%n",
			idx ++, src, srcp, dest, destp, sk->sk_state, icsk->icsk_ca_ops->name,
			len);

		if (set_new_cong_round) {
			spin_lock_bh(&((sk)->sk_lock.slock));
			if (!sock_owned_by_user(sk)) {
				(*tcp_set_congestion_control_ptr)(sk, sysctl_new_cong);
				// 如果listen的sk设置了icsk_ca_setsockopt，
				// 那么派生的child默认都是sk的cong，而不是系统默认的cong
				icsk->icsk_ca_setsockopt = 0;
			}
			spin_unlock_bh(&((sk)->sk_lock.slock));
		}
	}
}

static void get_timewait4_sock(const struct inet_timewait_sock *tw,
			       struct seq_file *f, int i, int *len)
{
	__be32 dest, src;
	__u16 destp, srcp;
	s32 delta = tw->tw_ttd - inet_tw_time_stamp();

	dest  = tw->tw_daddr;
	src   = tw->tw_rcv_saddr;
	destp = ntohs(tw->tw_dport);
	srcp  = ntohs(tw->tw_sport);

	seq_printf(f, "%4d: %08X:%04X %08X:%04X"
		" %02X %08X:%08X %02X:%08lX %08X %5d %8d %d %d %pK%n",
		i, src, srcp, dest, destp, tw->tw_substate, 0, 0,
		3, jiffies_delta_to_clock_t(delta), 0, 0, 0, 0,
		atomic_read(&tw->tw_refcnt), tw, len);
}

#define TMPSZ 150

static int tcp4_seq_show(struct seq_file *seq, void *v)
{
	struct tcp_iter_state *st;
	struct sock *sk = v;
	int len = 0;
	char available_cc[256];

	if (v == SEQ_START_TOKEN) {
		seq_printf(seq, "%-*s\n", TMPSZ - 1,
			   "  sl  local_address rem_address   st cong");
		sysctl_new_cong[TCP_CA_NAME_MAX-1] = '\0';
		(*tcp_get_available_congestion_control_ptr)(available_cc, 256);
		available_cc[255] = '\0';
		if (sysctl_set_new_cong && strstr(available_cc, sysctl_new_cong) != NULL) {
			set_new_cong_round = 1;
		} else {
			set_new_cong_round = 0;
		}
		sysctl_set_new_cong = 0;
		idx = 0;
		goto out; 
	}
	st = seq->private;

	switch (st->state) {
	case TCP_SEQ_STATE_LISTENING:
	case TCP_SEQ_STATE_ESTABLISHED:
		if (sk->sk_state == TCP_TIME_WAIT)
			;//get_timewait4_sock(v, seq, st->num, &len);
		else
			get_tcp4_sock(v, seq, st->num, &len);
		break;
	case TCP_SEQ_STATE_OPENREQ:
		;//get_openreq4(st->syn_wait_sk, v, seq, st->num, st->uid, &len);
		break;
	}
	if (len > 0)
		seq_printf(seq, "%*s\n", TMPSZ - 1 - len, "");
out:
	return 0;
}

static const struct file_operations tcp_afinfo_seq_fops = {
	.owner   = THIS_MODULE,
	.open    = tcp_seq_open,
	.read    = seq_read,
	.llseek  = seq_lseek,
	.release = seq_release_net
};

static struct tcp_seq_afinfo tcp4_seq_afinfo = {
	.name		= "conglist",
	.family		= AF_INET,
	.seq_fops	= &tcp_afinfo_seq_fops,
	.seq_ops	= {
		.show	= tcp4_seq_show,
	},
};

static int tcp4_proc_init_net(struct net *net)
{
	return tcp_proc_register(net, &tcp4_seq_afinfo);
}

static void tcp4_proc_exit_net(struct net *net)
{
	tcp_proc_unregister(net, &tcp4_seq_afinfo);
}

static struct pernet_operations tcp4_net_ops = {
	.init = tcp4_proc_init_net,
	.exit = tcp4_proc_exit_net,
};

int tcp4_proc_init(void)
{
	return register_pernet_subsys(&tcp4_net_ops);
}

void tcp4_proc_exit(void)
{
	unregister_pernet_subsys(&tcp4_net_ops);
}


//====================

struct info {
	struct task_struct *p;
	int sucess;
	int fail;
	void __user *buffer;
	size_t *lenp, *rlen;
};

static int do_copy_to_user(struct info *info, char *buf, int len)
{
	if (*info->rlen + len > *info->lenp)
		return -1;
	if (copy_to_user(info->buffer + *info->rlen, buf, len)) {
		return -2;
	}
	*info->rlen += len;
	return 0;
}

static int update_cong(const void *v, struct file *file, unsigned n)
{
	int err;
	char buf[256];
	int len;
	struct socket *sock = sock_from_file(file, &err);
	if (sock && sock->state == SS_UNCONNECTED && sock->sk->sk_protocol == IPPROTO_TCP) {
		struct info *info = (struct info *)v;
		struct sock *sk = sock->sk;
		struct inet_connection_sock *icsk = inet_csk(sk);
		spin_lock_bh(&((sk)->sk_lock.slock));
		if (icsk->icsk_ca_ops && !strcmp(icsk->icsk_ca_ops->name, sysctl_name)) {
			int update = 0;
			if (set_new_cong_round && !sock_owned_by_user(sk)) {
				(*tcp_set_congestion_control_ptr)(sk, sysctl_new_cong);
				info->sucess ++;
				update = 1;
			} else {
				info->fail ++;
			}
			//printk("%4d pid=%d name=%s fd=%d update=%d\n", idx++, info->p->pid, info->p->comm, n, update);
			len = sprintf(buf, "%4d pid=%d comm=%s fd=%d update=%d\n", idx++, info->p->pid, info->p->comm, n, update);
			do_copy_to_user(info, buf, len);
		}
		spin_unlock_bh(&((sk)->sk_lock.slock));
	}
	return 0;
}

int list_process(void __user *buffer, size_t *lenp, size_t *rlen)
{
	struct task_struct *g, *p;
	struct info info;
	char available_cc[256];
	char buf[256];
	int len;

	info.sucess = info.fail = 0;
	info.buffer = buffer;
	info.lenp = lenp;
	info.rlen = rlen;

	sysctl_new_cong[TCP_CA_NAME_MAX-1] = '\0';
	(*tcp_get_available_congestion_control_ptr)(available_cc, 256);
	available_cc[255] = '\0';
	if (sysctl_set_new_cong && strstr(available_cc, sysctl_new_cong) != NULL) {
		set_new_cong_round = 1;
	} else {
		set_new_cong_round = 0;
	}
	//printk("new_cong: %s available_congs: %s set_new_cong=%d\n", sysctl_new_cong, available_cc, set_new_cong_round);
	len = sprintf(buf, "new_cong: %s available_congs: %s set_new_cong=%d\n", sysctl_new_cong, available_cc, set_new_cong_round);
	do_copy_to_user(&info, buf, len);

	sysctl_set_new_cong = 0;
	idx = 0;

	rcu_read_lock();
	read_lock(tasklist_lock_ptr);
	for_each_process(p) {
	//for_each_process_thread(g, p) {
		task_lock(p);
		info.p = p;
		if (p->files)
			iterate_fd(p->files, 0, update_cong, &info);
		//printk("pid=%d comm=%s files=%p mm=%p\n", p->pid, p->comm, p->files, p->mm);
		task_unlock(p);
	}
	read_unlock(tasklist_lock_ptr);
	rcu_read_unlock();

	if (info.sucess + info.fail > 0) {
		//printk("update sucess=%d fail=%d\n", info.sucess, info.fail);
		len = sprintf(buf, "update sucess=%d fail=%d\n", info.sucess, info.fail);
		do_copy_to_user(&info, buf, len);
	}
	return 0;
}

int conglist_init(void)
{
	int ret = 0;

	ret = tcp4_proc_init();
	if (ret) {
		printk("register tcp4_proc err\n");
		return -1;
	}
	conglist_sysctl_init();
	return ret;
}

void conglist_exit(void)
{
	conglist_sysctl_exit();
	tcp4_proc_exit();
}
module_init(conglist_init);
module_exit(conglist_exit);

MODULE_LICENSE("GPL");
