#!/bin/bash

kernel_dir="$1"
sysmap_path="$1/System.map"
headfile="./conglist_symbols.c"

func_name=(
	"tcp_set_congestion_control"
	"tcp_get_available_congestion_control"
	"tasklist_lock"
)
func_num=${#func_name[@]}
find_func_addr() {
	func_addr=`cat $sysmap_path | grep "\<$1\>" | awk -F " " '{print $1}'`
	if [ -z "$func_addr" ] ; then
		echo "can't find func address : $1"
		exit 2
	else 
		echo "find func address : $1 [0x$func_addr]"
		echo "#define $1_addr 0x$func_addr" >> $headfile
	fi
}

write_headfile_head() {
	echo "#include \"conglist_symbols.h\"" >> $headfile
	echo "" >> $headfile
}
write_headfile_tail() {
	echo "" >> $headfile
}

if [ ! -d "$kernel_dir" ] || [ ! -f "$sysmap_path" ] ; then
	echo "can't find Symtep.map"
	exit 1
fi


true > $headfile
write_headfile_head
for ((i=0; i<$func_num; i++)) ; do
	find_func_addr ${func_name[$i]}
done
echo "int (*tcp_set_congestion_control_ptr)(struct sock *sk, const char *name) = (int (*)(struct sock *sk, const char *name))tcp_set_congestion_control_addr;" >> $headfile
echo "void (*tcp_get_available_congestion_control_ptr)(char *buf, size_t maxlen) = (void (*)(char *buf, size_t maxlen))tcp_get_available_congestion_control_addr;" >> $headfile
echo "rwlock_t *tasklist_lock_ptr = (rwlock_t *)tasklist_lock_addr;" >> $headfile
echo "" >> $headfile
write_headfile_tail
echo "symbols address write to $headfile done!"
