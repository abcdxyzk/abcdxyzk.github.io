#include "conglist_symbols.h"

#define tcp_set_congestion_control_addr 0xffffffff8158e200
#define tcp_get_available_congestion_control_addr 0xffffffff8158df10
#define tasklist_lock_addr 0xffffffff81943040
int (*tcp_set_congestion_control_ptr)(struct sock *sk, const char *name) = (int (*)(struct sock *sk, const char *name))tcp_set_congestion_control_addr;
void (*tcp_get_available_congestion_control_ptr)(char *buf, size_t maxlen) = (void (*)(char *buf, size_t maxlen))tcp_get_available_congestion_control_addr;
rwlock_t *tasklist_lock_ptr = (rwlock_t *)tasklist_lock_addr;


