#ifndef CONGLIST_SYMBOL_H
#define CONGLIST_SYMBOL_H
#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/tcp.h>
#include <net/tcp.h>

extern int (*tcp_set_congestion_control_ptr)(struct sock *sk, const char *name);
extern void (*tcp_get_available_congestion_control_ptr)(char *buf, size_t maxlen);
extern rwlock_t *tasklist_lock_ptr;
#endif
