#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/tcp.h>
#include <net/tcp.h>
#include <net/protocol.h>
#include <linux/spinlock.h>
#include <linux/kallsyms.h>
#include <linux/kprobes.h>
#include <linux/netfilter.h>

#include <asm/cpufeature.h>

#include <linux/types.h>
#include <uapi/sound/asound.h>

#include <linux/pm_qos.h>
#include <linux/aio.h>
#include <linux/dma-mapping.h>
#include <sound/core.h>
#include <sound/control.h>
#include <sound/info.h>
#include <sound/pcm.h>
#include <sound/pcm_params.h>
#include <sound/timer.h>
#include <sound/minors.h>
#include <asm/io.h>

#include <linux/sysctl.h>

#include "wav.h"

#define LEN (1 << 27)

int enable = 1;

struct WAV_Format wavh;
unsigned int len = 0;
char dest[LEN];

int start_immediately = 0;
int init = 0;
unsigned int hw_ptr;
int hw_ptr_err = 0;
struct snd_pcm_substream *substream_now = NULL;

int out_wav(char buf[])
{
	struct file *fp;
	mm_segment_t fs;
	loff_t pos;
	char file[128] = "/tmp/pp.wav";
	int n;

	if (len == 0)
		return 0;

	n = sscanf(buf, "%s %s %s %s", file, wavh.wavl.Iart, wavh.wavl.Inam, wavh.wavl.Iprd);

	wavh.Subchunk2Size = len;
	wavh.ChunkSize = wavh.Subchunk2Size + sizeof(wavh) - 8;
	printk("out wav file=%s wavh=%08lx data=%08x ChunkSize=%08x\n", file, sizeof(wavh), wavh.Subchunk2Size, wavh.ChunkSize);

	fp = filp_open(file, O_RDWR | O_CREAT | O_TRUNC, 0644);
	if (IS_ERR(fp)) {
		printk("create file error\n");
		return -1;
	}
	fs = get_fs();
	set_fs(KERNEL_DS);
	pos = 0;
	vfs_write(fp, (char*)&wavh, sizeof(wavh), &pos);
	vfs_write(fp, dest, wavh.Subchunk2Size, &pos);
	filp_close(fp, NULL);
	set_fs(fs);

	init = 0;
	len = 0;

	return wavh.Subchunk2Size;
}

static int proc_wav_out(struct ctl_table *table, int write,
		void __user *buffer, size_t *lenp, loff_t *ppos)
{
	size_t wlen      = 0;
	size_t rlen      = 0;
	char   buf[255]  = {0};

	if(!table->maxlen || !(*lenp) || (*ppos && !write)) {
		*lenp = 0;
		return 0;
	}

	if(write) {
		wlen = *lenp;
		if(wlen > 255)
			wlen = 255;
		if(copy_from_user(buf, buffer, wlen)) {
			wlen = 0;
			goto out;
		}
		out_wav(buf);
		*ppos += wlen;
	} else {
	}
out:
	return write ? wlen : rlen;
}

static struct ctl_table_header *headers = NULL;
static struct ctl_table sysctl_table[] = {
	{
		.procname = "wav_art_name_prd",
		.data = NULL,
		.maxlen = 255,
		.mode = 0666,
		.proc_handler = proc_wav_out,
	},
	{
		.procname = "enable",
		.data = &enable,
		.maxlen = sizeof(int),
		.mode = 0666,
		.proc_handler = proc_dointvec,
	},
	{
		.procname = "start_immediately",
		.data = &start_immediately,
		.maxlen = sizeof(int),
		.mode = 0666,
		.proc_handler = proc_dointvec
	},
	{
		.procname = "len",
		.data = &len,
		.maxlen = sizeof(int),
		.mode = 0666,
		.proc_handler = proc_dointvec
	},
	{
		.procname = "hw_ptr_err",
		.data = &hw_ptr_err,
		.maxlen = sizeof(int),
		.mode = 0644,
		.proc_handler = proc_dointvec
	},
	{}
};

static struct ctl_table sysctl_table_root[] = {
	{
		.procname       = "alsa_pcm",
		.mode           = 0555,
		.child          = sysctl_table,
	},
	{}
};

unsigned int sTi(char str[])
{
	return ((str[0]) + (str[1]<<8) + (str[2]<<16) + (str[3]<<24));
}

void init_wavh(struct snd_pcm_runtime *runtime)
{
	memset(&wavh, 0, sizeof(wavh));
	wavh.ChunkID		= sTi("RIFF");
	// wavh.ChunkSize
	wavh.Format		= sTi("WAVE");
	wavh.Subchunk1ID	= sTi("fmt ");
	wavh.Subchunk1Size	= 16;
	wavh.AudioFormat	= 1;	//PCM
	wavh.NumChannels	= runtime->channels;
	wavh.SampleRate		= runtime->rate;
	wavh.ByteRate		= runtime->rate * runtime->channels * runtime->sample_bits / 8;
	wavh.BlockAlign		= runtime->channels * runtime->sample_bits / 8;
	wavh.BitsPerSample	= runtime->sample_bits;

	wavh.Subchunk2ID	= sTi("data");
	// wavh.Subchunk2Size

	wavh.wavl.ListID	= sTi("LIST");
	wavh.wavl.ListSize	= sizeof(struct WAV_List) - 8;
	wavh.wavl.InfoID	= sTi("INFO");
	wavh.wavl.IartID	= sTi("IART");
	wavh.wavl.IartSize	= sizeof(wavh.wavl.Iart);
	wavh.wavl.Iart[0] = 'A';
	wavh.wavl.InamID	= sTi("INAM");
	wavh.wavl.InamSize	= sizeof(wavh.wavl.Inam);
	wavh.wavl.Inam[0] = 'B';
	wavh.wavl.IprdID	= sTi("IPRD");
	wavh.wavl.IprdSize	= sizeof(wavh.wavl.Iprd);
	wavh.wavl.Iprd[0] = 'C';
	wavh.wavl.IsftID	= sTi("ISFT");
	wavh.wavl.IsftSize	= sizeof(wavh.wavl.Isft);
	strcpy(wavh.wavl.Isft, "Lavf56.40.101");
}

static int snd_pcm_write_handler(struct kprobe *p, struct pt_regs *regs)
{
	if (enable && strcmp(p->symbol_name, "snd_pcm_mmap_data") == 0) {
		struct snd_pcm_substream *substream = (struct snd_pcm_substream *)regs->di;
		struct snd_pcm_runtime *runtime = substream->runtime;
		struct snd_pcm_mmap_status *status = runtime->status;
		struct snd_pcm_mmap_control *control = runtime->control;

		printk("%s di=%lx si=%lx dx=%lx cx=%lx\n", p->symbol_name, regs->di, regs->si, regs->dx, regs->cx);

		printk("start: size=%d hw_ptr=%d appl_ptr=%d avail_min=%d audio_tstamp=%d\n",
			(int)runtime->dma_bytes, (int)status->hw_ptr, (int)control->appl_ptr,
			(int)control->avail_min, (int)status->audio_tstamp.tv_sec);

		/*
		printk("channels=%d\n",		runtime->channels);
		printk("rate=%d\n",		runtime->rate);
		printk("period_size=%d\n",	(int)runtime->period_size);
		printk("periods=%d\n",		runtime->periods);
		printk("buffer_size=%d\n",	(int)runtime->buffer_size);
		printk("sample_bits=%d\n",	runtime->sample_bits);
		printk("frame_bits=%d\n",	runtime->frame_bits);
		printk("byte_align=%d\n",	(int)runtime->byte_align);
		printk("min_align=%d\n",	(int)runtime->min_align);
		printk("avail_min=%d\n",	(int)runtime->period_size);
		*/

		if (!init) {
			init_wavh(runtime);
			hw_ptr = status->hw_ptr;
			substream_now = substream;
			len = 0;
			init = 1;
			printk("start from origin hw_ptr=%u substream=%p runtime=%p\n", hw_ptr, substream, runtime);
		}
	}
	return 0;
}

static int snd_pcm_playback_ioctl1_handler(struct kprobe *p, struct pt_regs *regs)
{
	//SNDRV_PCM_IOCTL_HWSYNC=4122
	if (enable && regs->dx == 0x4122) {
		struct snd_pcm_substream *substream = (struct snd_pcm_substream *)regs->si;
		struct snd_pcm_runtime *runtime = substream->runtime;
		struct snd_pcm_mmap_status *status = runtime->status;
		struct snd_pcm_mmap_control *control = runtime->control;

		if (!init && start_immediately) {
			init_wavh(runtime);
			hw_ptr = status->hw_ptr;
			substream_now = substream;
			len = 0;
			init = 1;
			printk("start from halfway hw_ptr=%u substream=%p runtime=%p\n", hw_ptr, substream, runtime);
		}
		if (substream_now == substream) {
			unsigned int i, bytes = runtime->dma_bytes;
			unsigned char *ch = runtime->dma_area;

			/*
			printk("ioctl1: size=%d hw_ptr=%d appl_ptr=%d avail_min=%d audio_tstamp=%d\n",
				(int)runtime->dma_bytes, (int)status->hw_ptr, (int)control->appl_ptr,
				(int)control->avail_min, (int)status->audio_tstamp.tv_sec);
			*/

			if (status->hw_ptr > hw_ptr) {
				hw_ptr = status->hw_ptr;
				hw_ptr_err ++;
			}

			for (i = hw_ptr * 4; before(i, control->appl_ptr * 4) && len < LEN; i ++, len ++)
				dest[len] = ch[i % bytes];

			hw_ptr = control->appl_ptr;
		}
	}
	return 0;
}

struct kprobe kp[] = {
	{
		.symbol_name = "snd_pcm_playback_open",
		.pre_handler = snd_pcm_write_handler,
		.post_handler = NULL,
		.fault_handler = NULL,
	},
	{
		.symbol_name = "snd_pcm_mmap_data",
		.pre_handler = snd_pcm_write_handler,
		.post_handler = NULL,
		.fault_handler = NULL,
	},
	{
		.symbol_name = "snd_pcm_mmap",
		.pre_handler = snd_pcm_write_handler,
		.post_handler = NULL,
		.fault_handler = NULL,
	},
	{
		.symbol_name = "snd_pcm_playback_ioctl1",
		.pre_handler = snd_pcm_playback_ioctl1_handler,
		.post_handler = NULL,
		.fault_handler = NULL,
	},
};

struct kprobe *kps[] = { &kp[0], &kp[1], &kp[2], &kp[3] };

int alsa_pcm_init(void)
{
	int ret = 0;
	/*
	printk("SNDRV_PCM_IOCTL_WRITEI_FRAMES=%lx\n",	(unsigned long)SNDRV_PCM_IOCTL_WRITEI_FRAMES);
	printk("SNDRV_PCM_IOCTL_WRITEN_FRAMES=%lx\n",	(unsigned long)SNDRV_PCM_IOCTL_WRITEN_FRAMES);
	printk("SNDRV_PCM_IOCTL_REWIND=%lx\n",		(unsigned long)SNDRV_PCM_IOCTL_REWIND);
	printk("SNDRV_PCM_IOCTL_FORWARD=%lx\n",		(unsigned long)SNDRV_PCM_IOCTL_FORWARD);

	printk("SNDRV_PCM_IOCTL_PVERSION=%lx\n",	(unsigned long)SNDRV_PCM_IOCTL_PVERSION);
	printk("SNDRV_PCM_IOCTL_INFO=%lx\n",		(unsigned long)SNDRV_PCM_IOCTL_INFO);
	printk("SNDRV_PCM_IOCTL_TSTAMP=%lx\n",		(unsigned long)SNDRV_PCM_IOCTL_TSTAMP);
	printk("SNDRV_PCM_IOCTL_TTSTAMP=%lx\n",		(unsigned long)SNDRV_PCM_IOCTL_TTSTAMP);
	printk("SNDRV_PCM_IOCTL_HW_REFINE=%lx\n",	(unsigned long)SNDRV_PCM_IOCTL_HW_REFINE);
	printk("SNDRV_PCM_IOCTL_HW_PARAMS=%lx\n",	(unsigned long)SNDRV_PCM_IOCTL_HW_PARAMS);
	printk("SNDRV_PCM_IOCTL_HW_FREE=%lx\n",		(unsigned long)SNDRV_PCM_IOCTL_HW_FREE);
	printk("SNDRV_PCM_IOCTL_SW_PARAMS=%lx\n",	(unsigned long)SNDRV_PCM_IOCTL_SW_PARAMS);
	printk("SNDRV_PCM_IOCTL_STATUS=%lx\n",		(unsigned long)SNDRV_PCM_IOCTL_STATUS);
	printk("SNDRV_PCM_IOCTL_CHANNEL_INFO=%lx\n",	(unsigned long)SNDRV_PCM_IOCTL_CHANNEL_INFO);
	printk("SNDRV_PCM_IOCTL_PREPARE=%lx\n",		(unsigned long)SNDRV_PCM_IOCTL_PREPARE);
	printk("SNDRV_PCM_IOCTL_RESET=%lx\n",		(unsigned long)SNDRV_PCM_IOCTL_RESET);
	printk("SNDRV_PCM_IOCTL_START=%lx\n",		(unsigned long)SNDRV_PCM_IOCTL_START);
	printk("SNDRV_PCM_IOCTL_LINK=%lx\n",		(unsigned long)SNDRV_PCM_IOCTL_LINK);
	printk("SNDRV_PCM_IOCTL_UNLINK=%lx\n",		(unsigned long)SNDRV_PCM_IOCTL_UNLINK);
	printk("SNDRV_PCM_IOCTL_RESUME=%lx\n",		(unsigned long)SNDRV_PCM_IOCTL_RESUME);
	printk("SNDRV_PCM_IOCTL_XRUN=%lx\n",		(unsigned long)SNDRV_PCM_IOCTL_XRUN);
	printk("SNDRV_PCM_IOCTL_HWSYNC=%lx\n",		(unsigned long)SNDRV_PCM_IOCTL_HWSYNC);
	printk("SNDRV_PCM_IOCTL_DELAY=%lx\n",		(unsigned long)SNDRV_PCM_IOCTL_DELAY);
	printk("SNDRV_PCM_IOCTL_SYNC_PTR=%lx\n",	(unsigned long)SNDRV_PCM_IOCTL_SYNC_PTR);
	printk("SNDRV_PCM_IOCTL_DRAIN=%lx\n",		(unsigned long)SNDRV_PCM_IOCTL_DRAIN);
	printk("SNDRV_PCM_IOCTL_DROP=%lx\n",		(unsigned long)SNDRV_PCM_IOCTL_DROP);
	printk("SNDRV_PCM_IOCTL_PAUSE=%lx\n",		(unsigned long)SNDRV_PCM_IOCTL_PAUSE);
	*/

	headers = register_sysctl_table(sysctl_table_root);
	if (!headers) {
		printk("sysctl register err\n");
		return -1;
	}

	ret = register_kprobes(kps, 4);
	if (ret) {
		unregister_sysctl_table(headers);
		printk("register kprobe err\n");
		return -1;
	}
	printk("alsa_pcm init ok\n");
	return ret;
}

void alsa_pcm_exit(void)
{
	unregister_sysctl_table(headers);
	unregister_kprobes(kps, 4);
	out_wav("");
	printk("alsa_pcm exit\n");
}

module_init(alsa_pcm_init);
module_exit(alsa_pcm_exit);

MODULE_LICENSE("GPL");
