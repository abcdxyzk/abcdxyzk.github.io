#include <stdio.h>
#include <string.h>
#include <stdint.h>

#include "wav.h"

int main(int argc, char **argv)
{
	struct WAV_Format wavh;
	struct WAV_List *wavl = &wavh.wavl;
	FILE *fp;
	if (argc < 5) {
		printf("./%s X.wav art name prd\n", argv[0]);
		return -1;
	}
	fp = fopen(argv[1], "r+");
	fread(&wavh, sizeof(wavh), 1, fp);
	printf("old art=%s name=%s prd=%s\n", wavl->Iart, wavl->Inam, wavl->Iprd);
	strcpy(wavl->Iart, argv[2]);
	strcpy(wavl->Inam, argv[3]);
	strcpy(wavl->Iprd, argv[4]);
	printf("new art=%s name=%s prd=%s\n", wavl->Iart, wavl->Inam, wavl->Iprd);
	fseek(fp, 0, SEEK_SET);
	fwrite(&wavh, sizeof(wavh), 1, fp);
	return 0;
}
