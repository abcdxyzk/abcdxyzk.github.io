struct WAV_List {
	uint32_t ListID;	/* "LIST" */
	uint32_t ListSize;
	uint32_t InfoID;
	uint32_t IartID;
	uint32_t IartSize;
	char Iart[32];
	uint32_t InamID;
	uint32_t InamSize;
	char Inam[56];
	uint32_t IprdID;
	uint32_t IprdSize;
	char Iprd[64];
	uint32_t IsftID;
	uint32_t IsftSize;
	char Isft[16];
};

struct WAV_Format {
	uint32_t ChunkID;       /* "RIFF" */
	uint32_t ChunkSize;     /* 36 + Subchunk2Size */
	uint32_t Format;        /* "WAVE" */

	/* sub-chunk "fmt" */
	uint32_t Subchunk1ID;   /* "fmt " */
	uint32_t Subchunk1Size; /* 16 for PCM */
	uint16_t AudioFormat;   /* PCM = 1*/
	uint16_t NumChannels;   /* Mono = 1, Stereo = 2, etc. */
	uint32_t SampleRate;    /* 8000, 44100, etc. */
	uint32_t ByteRate;      /* = SampleRate * NumChannels * BitsPerSample/8 */
	uint16_t BlockAlign;    /* = NumChannels * BitsPerSample/8 */
	uint16_t BitsPerSample; /* 8bits, 16bits, etc. */

	struct WAV_List wavl;

	/* sub-chunk "data" */
	uint32_t Subchunk2ID;   /* "data" */
	uint32_t Subchunk2Size; /* data size */
};

