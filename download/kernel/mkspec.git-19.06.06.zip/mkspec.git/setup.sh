#!/bin/sh

uid=`id -u`
if [ $uid -ne 0 ] ; then
	echo "ERROR: must be root"
	exit 1
fi

if [ ! -f /usr/bin/lsb_release ] ; then
	echo "ERROR: need lsb_release, run: yum install redhat-lsb"
	exit 2;
fi

el=`lsb_release -r | awk -F"[.: \t]+" '{print $2}'`
if [ $el -ne 5 ] && [ $el -ne 6 ] && [ $el -ne 7 ] ; then
	echo "ERROR: must be el5 OR el6 OR el7"
	exit 3
fi

/bin/cp el$el/debugedit_el$el /usr/lib/rpm/debugedit_kk
/bin/cp /usr/lib/rpm/find-debuginfo.sh /usr/lib/rpm/find-debuginfo_kk.sh

line=`grep -n debugedit /usr/lib/rpm/find-debuginfo_kk.sh | awk -F: '{printf $1}'`
sed "$line a "'\ \ id=$(/usr/lib/rpm/debugedit_kk -b "$RPM_BUILD_DIR" -d "/usr/src/debug$REPLACE_COMP_DIR" \\' -i /usr/lib/rpm/find-debuginfo_kk.sh
sed "$line d" -i /usr/lib/rpm/find-debuginfo_kk.sh

# CentOS7编译3.10.0内核时生成的debugsources.list含有空行和////，空行cpio可以过滤，多个斜杠的会导致cpio去除usr/src/debug的写权限，导致编译失败
sed 's/<built-in>/<built-in>|\//' -i /usr/lib/rpm/find-debuginfo_kk.sh

echo "setup done"
