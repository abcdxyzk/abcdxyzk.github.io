# PHPExcel - DEPRECATED

PHPExcel last version, 1.8.1, was released in 2015. The project is no longer maintained and 
should not be used anymore.

All **users should migrate** to its direct successor [PhpSpreadsheet](https://github.com/PHPOffice/PhpSpreadsheet), or another alternative.

In a few months, the GitHub project will be marked as archived, so everything will be read-only.

## License

PHPExcel is licensed under [LGPL (GNU LESSER GENERAL PUBLIC LICENSE)](https://github.com/PHPOffice/PHPExcel/blob/master/license.md)
