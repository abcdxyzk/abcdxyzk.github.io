<?php
	//include_once('PHPWord/src/PhpWord/TemplateProcessor.php');
	include_once "vendor/autoload.php";
	$tmp=new \PhpOffice\PhpWord\TemplateProcessor('员工简历表.docx');
	//$tmp=new TemplateProcessor('员工简历表.doc');//打开模板
	$tmp->setValue('xm','李四');//替换变量name
	$tmp->setValue('zgh','1234');//替换变量mobile
	$tmp->saveAs('简历.docx');//另存为
