#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <unistd.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <stdlib.h>
#include <string.h>
#include <sys/time.h>
#include <errno.h>
#include <fcntl.h>
#include <time.h>
#include <sys/epoll.h>

#define MAX_FD		1024
#define MAX_EVENT	20

#define FD_LISTEN	1
#define FD_NORMAL	2
#define FD_SHUTDOWN	4

#define TIMEOUT		30
#define INTERVAL	10

#define USE_TIMEOUT
#define USE_NOBLOCK

struct epoll_ptr {
	int fd, type;
	time_t touch;
} eptr[MAX_FD];

int set_noblock(int fd)
{
#ifdef USE_NOBLOCK
	int flags = fcntl(fd, F_GETFL, 0);
	if (flags < 0) {
		printf("get socket flags fail.\n");
		return -1;
	}
	if (fcntl(fd, F_SETFL, flags | O_NONBLOCK) < 0) {
		perror("set socket O_NONBLOCK fail.\n");
		return -2;
	}
#endif
	return 0;
}

static int start_up(const char* _ip, int _port)
{
	int fd = socket(AF_INET, SOCK_STREAM, 0);
	if (fd < 0) {
		perror("socket");
		exit(-1);
	}

	if (set_noblock(fd))
		exit(-2);

	struct sockaddr_in local;
	local.sin_family = AF_INET;
	local.sin_port = htons(_port);
	local.sin_addr.s_addr = inet_addr(_ip);
	if (bind(fd, (struct sockaddr*)&local, sizeof(local)) < 0) {
		perror("bind");
		exit(-3);
	}
	if (listen(fd, 10) < 0) {
		perror("listen");
		exit(-4);
	}
	return fd;
}

int main(int argc, char* argv[])
{
	if (argc != 3) {
		printf("usage: %s ip port\n", argv[0]);
		return -1;
	}

	int i, ret;
	struct epoll_event ev, event[MAX_EVENT];
	int listenfd;
	int epfd;

	listenfd = start_up(argv[1], atoi(argv[2]));

	epfd = epoll_create1(0);
	if (epfd < 0) {
		printf("epoll_create1 error\n");
		return -2;
	}

	eptr[listenfd].fd    = listenfd;
	eptr[listenfd].type  = FD_LISTEN;
	eptr[listenfd].touch = time(NULL);
	ev.data.ptr = &eptr[listenfd];
	ev.events   = EPOLLIN | EPOLLET; // 边缘触发
	ret = epoll_ctl(epfd, EPOLL_CTL_ADD, listenfd, &ev);

	if (ret < 0) {
		printf("epoll_ctl error\n");
		return -3;
	}

	while (1)
	{
		int j, k, wait_count;
		int timeout_ms = INTERVAL * 1000;

#ifdef USE_TIMEOUT
		wait_count = epoll_wait(epfd, event, MAX_EVENT, timeout_ms);
#else
		wait_count = epoll_wait(epfd, event, MAX_EVENT, -1);
#endif
		if (wait_count < 0) {
			perror("epoll_wait");
			break;
		}

		// timeout no deal
		for (j = 0; j < wait_count; j ++)
		{
			struct epoll_ptr *ptr = (struct epoll_ptr *)event[j].data.ptr;
			int r, fd = ptr->fd;
			if (event[j].events & (EPOLLERR | EPOLLHUP)) {
				close(fd);
				continue;
			}

			ptr->touch = time(NULL);

			if (ptr->type == 1) {
				struct sockaddr_in client;
				socklen_t len = sizeof(client);
				int new_fd;
			listen_fd:
				new_fd = accept(fd, (struct sockaddr*)&client, &len);
				if (new_fd < 0) {
					if (errno != EAGAIN)
						perror("accept");
					printf("listen end\n");
					continue;
				}
				printf("get a new client fd=%d %s\n", new_fd, inet_ntoa(client.sin_addr));

				if (set_noblock(new_fd)) {
					close(new_fd);
					goto listen_fd;
				}

				eptr[new_fd].fd    = new_fd;
				eptr[new_fd].type  = FD_NORMAL;
				eptr[new_fd].touch = time(NULL);
				ev.data.ptr = &eptr[new_fd];
				ev.events   = EPOLLIN | EPOLLET; // 边缘触发
				r = epoll_ctl(epfd, EPOLL_CTL_ADD, new_fd, &ev);

				if (r < 0) {
					close(new_fd);
					printf("epoll_ctl err\n");
				}
				goto listen_fd;
			}

			if (event[j].events & EPOLLIN) {
				char buf[1024];
				ssize_t s;
			epoll_in:
				s  = read(fd, buf, sizeof(buf) - 1);
				if (s > 0) {
					buf[s] = 0;
					printf("clientsay#%s\n", buf);

					if (ptr->type & FD_SHUTDOWN)
						goto epoll_in;

					write(fd, buf, strlen(buf));

					eptr[fd].fd    = fd;
					eptr[fd].type  = 2;
					eptr[fd].touch = time(NULL);
					ev.data.ptr = &eptr[fd];
					ev.events   = EPOLLIN | EPOLLOUT | EPOLLET; // 边缘触发
					r = epoll_ctl(epfd, EPOLL_CTL_MOD, fd, &ev);
					if (r < 0) {
						close(fd);
						printf("epoll_ctl err\n");
					}
				} else if (s == 0) {
					printf("client quit!\n");
					close(fd);
				} else if (errno == EAGAIN) {
					; //printf("read again\n");
				} else {
					perror("read");
					close(fd);
				}
			} else if (event[j].events & EPOLLOUT) {
				char msg[128] = "hello\n";
				write(fd, msg, strlen(msg));
				printf("write msg fd=%d\n", fd);

				shutdown(fd, SHUT_WR);

				eptr[fd].fd    = fd;
				eptr[fd].type  = ptr->type | FD_SHUTDOWN;
				eptr[fd].touch = time(NULL);
				ev.data.ptr = &eptr[fd];
				ev.events   = EPOLLIN | EPOLLET; // 边缘触发
				r = epoll_ctl(epfd, EPOLL_CTL_MOD, fd, &ev);

				if (r < 0) {
					close(fd);
					printf("epoll_ctl err\n");
				}
			}
		}
	}
	printf("exit all\n");
	close(listenfd);
	return 0;
}
