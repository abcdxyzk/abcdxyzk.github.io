#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <unistd.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <stdlib.h>
#include <string.h>
#include <sys/time.h>
#include <errno.h>
#include <fcntl.h>
#include <time.h>
#include <poll.h>

#define MAXN		1024

#define TIMEOUT		30
#define INTERVAL	10

#define USE_TIMEOUT
#define USE_NOBLOCK

int set_noblock(int fd)
{
#ifdef USE_NOBLOCK
	int flags = fcntl(fd, F_GETFL, 0);
	if (flags < 0) {
		printf("get socket flags fail.\n");
		return -1;
	}
	if (fcntl(fd, F_SETFL, flags | O_NONBLOCK) < 0) {
		perror("set socket O_NONBLOCK fail.\n");
		return -2;
	}
#endif
	return 0;
}

static int start_up(const char* _ip, int _port)
{
	int fd = socket(AF_INET, SOCK_STREAM, 0);
	if (fd < 0) {
		perror("socket");
		exit(-1);
	}

	if (set_noblock(fd))
		exit(-2);

	struct sockaddr_in local;
	local.sin_family = AF_INET;
	local.sin_port = htons(_port);
	local.sin_addr.s_addr = inet_addr(_ip);
	if (bind(fd, (struct sockaddr*)&local, sizeof(local)) < 0) {
		perror("bind");
		exit(-3);
	}
	if (listen(fd, 10) < 0) {
		perror("listen");
		exit(-4);
	}
	return fd;
}

int main(int argc, char* argv[])
{
	if (argc != 3) {
		printf("usage: %s ip port\n", argv[0]);
		return -1;
	}

	int max_listen, maxi;
	time_t fd_touch[MAXN], fd_writeable[MAXN];
	int i;
	struct pollfd pollfds[MAXN];
	int array_size = sizeof(pollfds)/sizeof(pollfds[0]);
	int listenfd;

	listenfd = start_up(argv[1], atoi(argv[2]));

	pollfds[0].fd = listenfd;
	pollfds[0].events = POLLIN | POLLERR | POLLHUP | POLLNVAL;
	fd_touch[0] = time(NULL);
	fd_writeable[0] = 0;

	maxi = 1;
	max_listen = 1;

	for (i = max_listen; i < array_size; i ++) {
		pollfds[i].fd = -1;
		fd_writeable[i] = 1;
	}

	while (1)
	{
		int j, k, ret;
		int timeout_ms = INTERVAL * 1000;

#ifdef USE_TIMEOUT
		ret = poll(pollfds, maxi, timeout_ms);
#else
		ret = poll(pollfds, maxi, -1);
#endif
		if (ret == -1) {
			perror("poll");
			break;
		}

		time_t now = time(NULL);
		for (i = 0; i < maxi; i++) {
			if (pollfds[i].fd > 0) {
				if (i >= max_listen && now - fd_touch[i] >= TIMEOUT) {
					printf("timeout fd=%d\n", pollfds[i].fd);
					close(pollfds[i].fd);
					pollfds[i].fd = -1;
					continue;
				}
			}
		}

		for (j = 0; j < array_size; j ++)
		{
			if (pollfds[j].fd < 0)
				continue;

			if (pollfds[j].revents & (POLLERR | POLLHUP | POLLNVAL)) {
				close(pollfds[j].fd);
				pollfds[j].fd = -1;
				continue;
			}

			fd_touch[j] = time(NULL);

			if (j < max_listen && (pollfds[j].revents & POLLIN)) {
				struct sockaddr_in client;
				socklen_t len = sizeof(client);
				int new_fd = accept(pollfds[j].fd, (struct sockaddr*)&client, &len);
				if (new_fd < 0) {
					if (errno != EAGAIN)
						perror("accept");
					continue;
				}
				printf("get a new client %s\n", inet_ntoa(client.sin_addr));

				if (set_noblock(new_fd)) {
					close(new_fd);
					continue;
				}

				for (k = max_listen; k < array_size; k ++) {
					if (pollfds[k].fd < 0) {
						pollfds[k].fd = new_fd;
						pollfds[k].events = POLLIN | POLLERR | POLLHUP | POLLNVAL;

						fd_touch[k] = time(NULL);
						fd_writeable[k] = 1;
						if (k+1 > maxi)
							maxi = k+1;
						break;
					}
				}
				if (k == array_size) {
					close(new_fd);
					printf("pollfds full\n");
				}
			}
			if (j < max_listen)
				continue;

			if (pollfds[j].revents & POLLIN) {
				char buf[1024];
				ssize_t s = read(pollfds[j].fd, buf, sizeof(buf) - 1);
				if (s > 0) {
					buf[s] = 0;
					printf("clientsay#%s\n",buf);
					if (fd_writeable[j]) {
						write(pollfds[j].fd, buf, strlen(buf));
						pollfds[j].events |= POLLOUT;
					}
				} else if (s == 0) {
					printf("client quit!\n");
					close(pollfds[j].fd);
					pollfds[j].fd = -1;
				} else {
					perror("read");
					close(pollfds[j].fd);
					pollfds[j].fd = -1;
				}
			} else if (pollfds[j].revents & POLLOUT) {
				char msg[128] = "hello\n";
				write(pollfds[j].fd, msg, strlen(msg));
				printf("write msg fd=%d\n", pollfds[j].fd);
				shutdown(pollfds[j].fd, SHUT_WR);
				pollfds[j].events &= ~POLLOUT;
				fd_writeable[j] = 0;
			}
		}
	}
	printf("exit all\n");
	close(listenfd);
	return 0;
}
