#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <unistd.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <stdlib.h>
#include <string.h>
#include <sys/time.h>
#include <errno.h>
#include <fcntl.h>
#include <time.h>

#define MAXN		1024

#define TIMEOUT		30
#define INTERVAL	10

#define USE_TIMEOUT
#define USE_NOBLOCK

int set_noblock(int fd)
{
#ifdef USE_NOBLOCK
	int flags = fcntl(fd, F_GETFL, 0);
	if (flags < 0) {
		printf("get socket flags fail.\n");
		return -1;
	}
	if (fcntl(fd, F_SETFL, flags | O_NONBLOCK) < 0) {
		perror("set socket O_NONBLOCK fail.\n");
		return -2;
	}
#endif
	return 0;
}

static int start_up(const char* _ip, int _port)
{
	int fd = socket(AF_INET, SOCK_STREAM, 0);
	if (fd < 0) {
		perror("socket");
		exit(-1);
	}

	if (set_noblock(fd))
		exit(-2);

	struct sockaddr_in local;
	local.sin_family = AF_INET;
	local.sin_port = htons(_port);
	local.sin_addr.s_addr = inet_addr(_ip);
	if (bind(fd, (struct sockaddr*)&local, sizeof(local)) < 0) {
		perror("bind");
		exit(-3);
	}
	if (listen(fd, 10) < 0) {
		perror("listen");
		exit(-4);
	}
	return fd;
}

int main(int argc, char* argv[])
{
	if (argc != 3) {
		printf("usage: %s ip port\n", argv[0]);
		return -1;
	}

	int maxfd = 0, max_listen;
	fd_set rfds, wfds;
	int fd_arr[MAXN], fd_writeable[MAXN];
	time_t fd_touch[MAXN];
	int i;
	int array_size = sizeof(fd_arr)/sizeof(fd_arr[0]);
	int listenfd;

	listenfd = start_up(argv[1], atoi(argv[2]));
	fd_arr[0] = listenfd;
	fd_touch[0] = time(NULL);
	fd_writeable[0] = 0;

	max_listen = 1;

	for (i = max_listen; i < array_size; i ++) {
		fd_arr[i] = -1;
		fd_writeable[i] = 1;
	}

	while (1)
	{
		int j, k, ret;
		time_t now = time(NULL);
		FD_ZERO(&rfds);
		FD_ZERO(&wfds);
		for (i = 0; i < array_size; i++) {
			if (fd_arr[i] > 0) {
				if (i >= max_listen && now - fd_touch[i] >= TIMEOUT) {
					printf("timeout fd=%d\n", fd_arr[i]);
					close(fd_arr[i]);
					fd_arr[i] = -1;
					continue;
				}

				FD_SET(fd_arr[i], &rfds);
				if (fd_writeable[i])
					FD_SET(fd_arr[i], &wfds);
				if (fd_arr[i] > maxfd)
					maxfd = fd_arr[i];
			}
		}

#ifdef USE_TIMEOUT
		struct timeval timeout = { .tv_sec = INTERVAL, };
		ret = select(maxfd + 1, &rfds, &wfds, NULL, &timeout);
#else
		ret = select(maxfd + 1, &rfds, &wfds, NULL, NULL);
#endif
		if (ret == -1) {
			perror("select");
			break;
		}
		if (ret == 0) {
			continue;
		}

		for (j = 0; j < array_size; j ++)
		{
			if (fd_arr[j] < 0)
				continue;

			fd_touch[j] = time(NULL);

			if (j < max_listen && FD_ISSET(fd_arr[j], &rfds)) {
				struct sockaddr_in client;
				socklen_t len = sizeof(client);
				int new_fd = accept(fd_arr[j], (struct sockaddr*)&client, &len);
				if (new_fd < 0) {
					perror("accept");
					continue;
				}
				printf("get a new client %s\n", inet_ntoa(client.sin_addr));

				if (set_noblock(new_fd)) {
					close(new_fd);
					continue;
				}

				for (k = max_listen; k < array_size; k ++) {
					if (fd_arr[k] < 0) {
						fd_arr[k] = new_fd;
						fd_writeable[k] = 1;
						fd_touch[k] = time(NULL);
						if (new_fd > maxfd)
							maxfd = new_fd;
						break;
					}
				}
				if (k == array_size) {
					close(new_fd);
					printf("fd_arr full\n");
				}
			}
			if (j < max_listen)
				continue;

			if (FD_ISSET(fd_arr[j], &rfds)) {
				char buf[1024];
				ssize_t s = read(fd_arr[j], buf, sizeof(buf) - 1);
				if (s > 0) {
					buf[s] = 0;
					printf("clientsay#%s\n",buf);
					if (fd_writeable[j])
						write(fd_arr[j], buf, strlen(buf));
				} else if (s == 0) {
					printf("client quit!\n");
					close(fd_arr[j]);
					fd_arr[j] = -1;
				} else {
					perror("read");
					close(fd_arr[j]);
					fd_arr[j] = -1;
				}
			} else if (FD_ISSET(fd_arr[j], &wfds)) {
				char msg[128] = "hello\n";
				write(fd_arr[j], msg, strlen(msg));
				printf("write msg fd=%d\n", fd_arr[j]);
				shutdown(fd_arr[j], SHUT_WR);
				fd_writeable[j] = 0;
			}
		}
	}
	printf("exit all\n");
	close(listenfd);
	return 0;
}
