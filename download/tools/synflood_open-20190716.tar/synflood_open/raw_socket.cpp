
#include <errno.h>
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/types.h>
#include <errno.h>
#include <sys/param.h>
#include <string.h>
#include <semaphore.h>
#include <fcntl.h>
#include <time.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#include <sys/socket.h>
#include <netinet/in.h>
#include <netinet/ip.h>
#include <netinet/tcp.h>
#include <netinet/udp.h>
#include <arpa/inet.h>
#include <errno.h>

#include <netinet/ip6.h>

#include "raw_socket.h"


CWsRawSocket::CWsRawSocket()
: m_iRawSocket(-1),
m_iRawSocket6(-1)
{
	m_iRawSocket = socket(AF_INET, SOCK_RAW, IPPROTO_RAW);
	if (m_iRawSocket < 0) {
		perror("Create raw tcp socket");
		exit(1);
	}

	m_iRawSocket6 = socket(AF_INET6, SOCK_RAW, IPPROTO_TCP);
	if (m_iRawSocket6 < 0) {
		perror("Create raw tcp socket");
		exit(1);
	}
}

CWsRawSocket::~CWsRawSocket()
{
	if (m_iRawSocket >= 0) {
		close(m_iRawSocket);
		m_iRawSocket = -1;
	}

	if (m_iRawSocket6 >= 0) {
		close(m_iRawSocket6);
		m_iRawSocket6 = -1;
	}
}

unsigned short CWsRawSocket::GetChecksum( unsigned short* pData, unsigned short usIPHdr)
{
	unsigned int cksum = 0;
	while (usIPHdr > 1) {
		cksum += *pData++;
		usIPHdr -= sizeof(unsigned short);
	}

	if (usIPHdr) {
		cksum += *(unsigned char*)pData;
	}
	cksum = (cksum >> 16) + (cksum & 0xffff);
	cksum += (cksum >>16);
	return (unsigned short)(~cksum);
}

unsigned short CWsRawSocket::GetTcpUdpChecksum( unsigned short* pTcpUdpHead, void* tcpdata, unsigned short  usUdpLen )
{
	unsigned short	usPsHdr = sizeof(struct PseudoHdr);	// Length of pseudo-header.
	unsigned short *pTmp = (unsigned short*)tcpdata;          // Pointer to pseudo-header.
	unsigned long   ulSum = 0;

	while (usPsHdr > 0) {
		ulSum += *pTmp++;
		usPsHdr -= 2;
	}

	while (usUdpLen > 1) {
		ulSum += *pTcpUdpHead++;
		usUdpLen -= 2;
	}

	if (usUdpLen > 0)
		ulSum += *(unsigned char*)pTcpUdpHead;

	ulSum = (((ulSum >> 16) | (ulSum << 16)) + ulSum) >> 16;
	return (unsigned short)~ulSum;
}

bool CWsRawSocket::SendRawData(char* pIpData, int iLen)
{
	unsigned short usLen, usIpHead, usRawPort = 0;
	struct sockaddr_in sSaAddr;
	struct iphdr * pIpHead;
	struct PseudoHdr sPseudoHead;

	pIpHead = (struct iphdr*) pIpData;
	if (iLen!=ntohs(pIpHead->tot_len)) {
		printf("****** %s : Error len %d, ip len %d\n", __FUNCTION__, iLen, ntohs(pIpHead->tot_len));
		return false;
	}

	usIpHead	= pIpHead->ihl*4;
	usLen		= iLen - usIpHead;
	pIpHead->check	= 0;
	pIpHead->check	= GetChecksum((unsigned short*)pIpHead, usIpHead);

	sPseudoHead.uiSrcIp	= pIpHead->saddr;
	sPseudoHead.uiDstIp	= pIpHead->daddr;
	sPseudoHead.ucUser	= 0;
	sPseudoHead.ucProtocol	= pIpHead->protocol;
	sPseudoHead.usLen	= htons(usLen);

	if (pIpHead->protocol == IPPROTO_TCP) {
		struct tcphdr* pTcpHead = (struct tcphdr*) (pIpData+usIpHead);
		usRawPort = pTcpHead->dest;
		pTcpHead->check = 0;
		pTcpHead->check = GetTcpUdpChecksum ((unsigned short*) pTcpHead, &sPseudoHead, usLen);
		if (pTcpHead->check==0)
			pTcpHead->check=0xFFFF;

	} else if (pIpHead->protocol == IPPROTO_UDP) {
		struct udphdr* pUdpHead = (struct udphdr*) (pIpData+usIpHead);
		usRawPort = pUdpHead->dest;
		pUdpHead->check = 0;
		pUdpHead->check = GetTcpUdpChecksum ((unsigned short*) pUdpHead, &sPseudoHead, usLen);
		if (pUdpHead->check==0)
			pUdpHead->check=0xFFFF;
	} else {
		printf("****** %s : Error protocol %d !\n", __FUNCTION__, pIpHead->protocol);
		return false;
	}

	memset(&sSaAddr, 0, sizeof(sSaAddr));
	sSaAddr.sin_family	= AF_INET;
	sSaAddr.sin_port	= usRawPort;
	sSaAddr.sin_addr.s_addr	= pIpHead->daddr;

	if (sendto(m_iRawSocket, pIpData, iLen, 0, (struct sockaddr *)&sSaAddr, sizeof(sSaAddr)) >0)
		return true;
//	perror("Send data");
	return false;
}


// ipv6

typedef unsigned short u16;
typedef unsigned u32;
extern u16 csum_fold(__wsum csum);
extern __wsum csum_tcpudp_nofold(__be32 saddr, __be32 daddr,
				   unsigned short len,
				   unsigned short proto,
				   __wsum sum);

unsigned csum_partial_u16(unsigned short* pTcpUdpHead, unsigned short usUdpLen, unsigned long ulSum)
{
	while (usUdpLen > 1) {
		ulSum += *pTcpUdpHead++;
		usUdpLen -= 2;
	}

	if (usUdpLen > 0)
		ulSum += *(unsigned char*)pTcpUdpHead;

	ulSum = (ulSum & 0xffff) + (ulSum >> 16);
	ulSum = (ulSum & 0xffff) + (ulSum >> 16);
	return ulSum;
}

__sum16 csum_ipv6_magic(struct in6_addr *saddr,
                        struct in6_addr *daddr,
                        __u32 len, unsigned short proto,
                        __wsum csum)
{

        int carry;
        __u32 ulen;
        __u32 uproto;
        __u32 sum = (u32)csum;

        sum += (u32)saddr->s6_addr32[0];
        carry = (sum < (u32)saddr->s6_addr32[0]);
        sum += carry;

        sum += (u32)saddr->s6_addr32[1];
        carry = (sum < (u32)saddr->s6_addr32[1]);
        sum += carry;

        sum += (u32)saddr->s6_addr32[2];
        carry = (sum < (u32)saddr->s6_addr32[2]);
        sum += carry;

        sum += (u32)saddr->s6_addr32[3];
        carry = (sum < (u32)saddr->s6_addr32[3]);
        sum += carry;

        sum += (u32)daddr->s6_addr32[0];
        carry = (sum < (u32)daddr->s6_addr32[0]);
        sum += carry;

        sum += (u32)daddr->s6_addr32[1];
        carry = (sum < (u32)daddr->s6_addr32[1]);
        sum += carry;

        sum += (u32)daddr->s6_addr32[2];
        carry = (sum < (u32)daddr->s6_addr32[2]);
        sum += carry;

        sum += (u32)daddr->s6_addr32[3];
        carry = (sum < (u32)daddr->s6_addr32[3]);
        sum += carry;

        ulen = (u32)htonl((__u32) len);
        sum += ulen;
        carry = (sum < ulen);
        sum += carry;

        uproto = (u32)htonl(proto);
        sum += uproto;
        carry = (sum < uproto);
        sum += carry;

        return csum_fold((__wsum)sum);
}

bool CWsRawSocket::SendRawDataIpv6(char* pIpData, int iLen, int sin6_scope_id)
{
	unsigned short usLen, usIpHead, usRawPort = 0;
	struct sockaddr_in6 sSaAddr;
	struct ip6_hdr * pIpHead;
	usIpHead	= sizeof(struct ip6_hdr);

	pIpHead = (struct ip6_hdr*) pIpData;
	if (iLen != ntohs(pIpHead->ip6_plen) + usIpHead) {
		printf("****** %s : Error len %d, ip len %d\n", __FUNCTION__, iLen, ntohs(pIpHead->ip6_plen));
		return false;
	}

	usLen = iLen - usIpHead;
	short ucProtocol = pIpHead->ip6_nxt;

	if (ucProtocol == IPPROTO_TCP) {
		struct tcphdr* pTcpHead = (struct tcphdr*) (pIpData+usIpHead);
		usRawPort = pTcpHead->dest;
		pTcpHead->check = 0;
		pTcpHead->check = csum_ipv6_magic(&pIpHead->ip6_src, &pIpHead->ip6_dst, usLen, ucProtocol, csum_partial_u16((unsigned short*)pTcpHead, usLen, 0));
		if (pTcpHead->check == 0)
			pTcpHead->check = 0xFFFF;

	} else if (ucProtocol == IPPROTO_UDP) {
		struct udphdr* pUdpHead = (struct udphdr*) (pIpData+usIpHead);
		usRawPort = pUdpHead->dest;
		pUdpHead->check = 0;
		pUdpHead->check = csum_ipv6_magic(&pIpHead->ip6_src, &pIpHead->ip6_dst, usLen, ucProtocol, csum_partial_u16((unsigned short*)pUdpHead, usLen, 0));
		if (pUdpHead->check == 0)
			pUdpHead->check = 0xFFFF;
	} else {
		printf("****** %s : Error protocol %d !\n", __FUNCTION__, ucProtocol);
		return false;
	}

	memset(&sSaAddr, 0, sizeof(sSaAddr));
	sSaAddr.sin6_family	= AF_INET6;
	sSaAddr.sin6_port	= 0; // must set 0, not  usRawPort;
	sSaAddr.sin6_addr	= pIpHead->ip6_dst;
	sSaAddr.sin6_scope_id	= sin6_scope_id;

	int val = 1;
	setsockopt(m_iRawSocket6, IPPROTO_IPV6, IPV6_HDRINCL, &val, sizeof (val));

	if (sendto(m_iRawSocket6, pIpData, iLen, 0, (struct sockaddr *)&sSaAddr, sizeof(sSaAddr)) > 0)
		return true;
	perror("Send data");
	return false;
}

