#ifndef _____WS_RAW_SOCKET_____
#define _____WS_RAW_SOCKET_____
#pragma once

#include <linux/types.h>
#include <sys/types.h>
#include <unistd.h>

class CWsRawSocket
{
#pragma pack(1)
	struct PseudoHdr
	{
		unsigned int uiSrcIp;
		unsigned int uiDstIp;
		char	ucUser;
		char	ucProtocol;
		unsigned short usLen;
	};
#pragma pack()

protected:
	CWsRawSocket();
	~CWsRawSocket();

public:
	static CWsRawSocket& Instance()
	{
		static CWsRawSocket singleton;
		return singleton;
	}

	bool SendRawData(char* pIpData, int iLen);
	bool SendRawDataIpv6(char* pIpData, int iLen, int sin6_scope_id);

protected:
	unsigned short GetChecksum(unsigned short* pData, unsigned short usIPHdr);
	unsigned short GetTcpUdpChecksum(unsigned short* pTcpUdpHead, void* tcpdata, unsigned short usUdpLen);

protected:
	int m_iRawSocket;
	int m_iRawSocket6;

};

#endif
